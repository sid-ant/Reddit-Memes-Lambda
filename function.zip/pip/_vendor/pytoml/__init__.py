from .core import TomlError
from .parser import load, loads
from .writer import dump, dumps
